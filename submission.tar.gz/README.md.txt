The purpose of this game is to survive as long as possible to get a higher score, avoiding the red pillars that will end gravity bird's run.
The pillars are dodged by switching the direction of gravity to move your bird vertically, as well as with limited horizontal movement.

The controls are:
A (z): Flip gravity to make gravity bird fall upwards or downwards
LeftArrow : Holding this button will move gravity bird left as far as the game will allow
RighArrow : Holding this button will move gravity bird right as far as the game will allow

Hit Backspace at any time to return to the home screen.
Hit Enter to start the game.