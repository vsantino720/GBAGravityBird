/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x10 playergu playergu.png 
 * Time-stamp: Monday 04/05/2021, 21:34:32
 * 
 * Image Information
 * -----------------
 * playergu.png 15@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYERGU_H
#define PLAYERGU_H

extern const unsigned short playergu[150];
#define PLAYERGU_SIZE 300
#define PLAYERGU_LENGTH 150
#define PLAYERGU_WIDTH 15
#define PLAYERGU_HEIGHT 10

#endif

