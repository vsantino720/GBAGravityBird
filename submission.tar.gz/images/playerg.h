/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x10 playerg playerg.png 
 * Time-stamp: Monday 04/05/2021, 02:26:42
 * 
 * Image Information
 * -----------------
 * playerg.png 15@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYERG_H
#define PLAYERG_H

extern const unsigned short playerg[150];
#define PLAYERG_SIZE 300
#define PLAYERG_LENGTH 150
#define PLAYERG_WIDTH 15
#define PLAYERG_HEIGHT 10

#endif

